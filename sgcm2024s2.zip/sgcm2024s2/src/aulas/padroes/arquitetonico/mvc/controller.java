package aulas.padroes.arquitetonico.mvc;

public class controller {
    public static void main(String[] args) {
        System.out.println("A camada Controller age como um intermediário entre a camada de dados (Model) e a camada de apresentação (View).");
    }
}