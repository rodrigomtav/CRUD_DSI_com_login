package aulas.padroes.arquitetonico.mvc;

public class model {
    public static void main(String[] args) {
        System.out.println("Na camada Model devem ser mantidos todos os códigos esponsáveis pela lógica do negócio.  É essa camada que se comunica diretamente com o banco de dados");
    }
}