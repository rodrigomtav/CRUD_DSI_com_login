package aulas.padroes.arquitetonico.mvc;

public class view {
    public static void main(String[] args) {
        System.out.println("A camada View deve conter tudo o que se refere à interface com o usuário.");
    }
}