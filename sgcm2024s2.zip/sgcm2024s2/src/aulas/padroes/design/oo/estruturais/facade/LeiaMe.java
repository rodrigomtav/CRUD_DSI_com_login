package aulas.padroes.design.oo.estruturais.facade;

import java.io.File;
import java.io.FileWriter;

/*
Implementação do padrão de design orientado a objeto Facade, de modo a "esconder" a complexidade da criação de arquivo.
*/
public class LeiaMe {
    
    public void criarLeiaMe(String diretorio, String autor, String mensagem) {
        
        try {
            
            File arquivo = new File(diretorio + "LEIAME");
            FileWriter escritor = new FileWriter(arquivo, true);
            
            escritor.write("\n---");
            
            escritor.write("\nAutor: " + autor + "\n");
            escritor.write("Mensagem: " + mensagem + "\n");
            
            escritor.write("---");
            
            escritor.close();
            
        } catch(Exception ex) {
            ex.printStackTrace();
        }
        
    }
    
}