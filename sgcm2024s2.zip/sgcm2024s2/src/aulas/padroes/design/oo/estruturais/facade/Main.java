package aulas.padroes.design.oo.estruturais.facade;

public class Main {
    public static void main(String[] args) {
        
        new LeiaMe().criarLeiaMe("./", "Mário Popolin Neto", "Exemplo do padrão Facade.");
        
    }
}