package aulas.padroes.design.oo.criacionais;

public class Singleton {
    
    // objeto único da classe Singleton a ser retornado por getInstance 
    private static Singleton singleton;
    
    private Singleton() {        
    }
    
    public static Singleton getInstance() {
        if( singleton == null ) {
            singleton = new Singleton();
        }
        
        return singleton;
    }
    
}