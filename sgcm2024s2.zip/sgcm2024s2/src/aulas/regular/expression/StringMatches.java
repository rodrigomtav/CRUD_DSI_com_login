package aulas.regular.expression;

public class StringMatches {
    public static void main(String[] args) {
        
        String str; // cadeia de caracteres para ser testada      
        String regex; // padrão por expresão regular
        
        str = "1";
        regex = "\\d"; // \\ vão dar origem a \
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "1";
        regex = "\\d\\d\\d\\d\\d-\\d\\d\\d";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "14680-000";
        regex = "\\d\\d\\d\\d\\d-\\d\\d\\d";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "14680-000";
        regex = "\\w";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "m";
        regex = "\\w";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = " ";
        regex = "\\s";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "    ";
        regex = "\\s";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "    ";
        regex = "\\s+"; // + modifica 1 ... n
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "";
        regex = "\\s+";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "";
        regex = "\\s*"; // * modifica 0 ... n
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "          ";
        regex = "\\s*";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "12";
        regex = "\\d{5}-\\d{3}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "14340-000";
        regex = "\\d{5}-\\d{3}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "14340-000";
        regex = "\\d{5}###\\d{3}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "14340###000";
        regex = "\\d{5}###\\d{3}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "14340000";
        regex = "\\d{8}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "415.974.137-55";
        regex = "\\d{3}.\\d{3}.\\d{3}-\\d{2}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "415";
        regex = "\\d{3,}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "41";
        regex = "\\d{3,}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "4155";
        regex = "\\d{3,}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "a";
        regex = "[aeiou]";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "aa";
        regex = "[aeiou]";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "m";
        regex = "[aeiou]";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "mmmm";
        regex = "[aeiou]+";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "aaaaa";
        regex = "[aeiou]+";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "aaaaa";
        regex = "[a-z]+";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "aAaaa";
        regex = "[a-z]+";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "aAaaa";
        regex = "[A-Za-z]+";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "aAaaa";
        regex = "[A-Z][a-z]+";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "Mario";
        regex = "[A-Z][a-z]+";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "Mario";
        regex = "[A-Z][a-z]+(\\s[A-Z][a-z]+)*";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "Mario Popolin";
        regex = "[A-Z][a-z]+(\\s[A-Z][a-z]+)*";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "Mario Popolin Neto";
        regex = "[A-Z][a-z]+(\\s[A-Z][a-z]+)*";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "Mario  Popolin Neto";
        regex = "[A-Z][a-z]+(\\s[A-Z][a-z]+)*";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        str = "Mario     Popolin  Neto";
        regex = "[A-Z][a-z]+(\\s+[A-Z][a-z]+)*";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
        regex = "\\s+";
        str = str.replaceAll(regex, " ");
        System.out.println("|" + str + "|");
        
        str = "Mario     Popolin  Neto";
        regex = "\\s+";
        System.out.println("|" + str + "|");
        String[] palavras = str.split(regex);
        for ( String s : palavras ) {
            System.out.println(s);
        }
        
        // +55(16)3716-2541
        // (16)3716-2541
        // +15(16)92585-2541
        // (16)92585-2541
        // +133(16)92585-2541
        str = "+55(16)3716-2541";
        regex = "(\\+\\d{2,})?\\(\\d{2}\\)\\d{4,5}-\\d{4}";
        System.out.println("|" + str + "| |" + regex + "| >> " + str.matches(regex) );
        
    }
}