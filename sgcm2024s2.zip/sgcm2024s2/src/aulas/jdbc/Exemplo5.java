package aulas.jdbc;

import java.sql.SQLException;
import model.TipoUsuario;

public class Exemplo5 {
    public static void main(String[] args) throws Exception {
        
        TipoUsuario tipo = new TipoUsuario();
        
        tipo.setId(13);
        tipo.setNome("Usuário 13");
        tipo.setModuloAdministrativo("N");
        tipo.setModuloAgendamento("N");        
        tipo.setModuloAtendimento("S");       
             
//        tipo.save();
        
        tipo = new TipoUsuario();
        tipo.setId(23);
        
        System.out.println( tipo.load() );        
        System.out.println("tipo.getNome(): " + tipo.getNome() );
        System.out.println("tipo.getModuloAdministrativo(): " 
                + tipo.getModuloAdministrativo() );
        System.out.println("tipo.getModuloAgendamento(): " 
                + tipo.getModuloAgendamento() );
        System.out.println("tipo.getModuloAtendimento(): " 
                + tipo.getModuloAtendimento() );
        
        tipo.setModuloAdministrativo("S");
        tipo.setModuloAgendamento("S");
        tipo.setModuloAtendimento("S");
        tipo.save();
        

//        tipo.delete();


        tipo = new TipoUsuario();
        tipo.setId(50);        
        System.out.println( tipo.load() );
        
        
        tipo.disconnectFromDatabase();
        
    } 
}