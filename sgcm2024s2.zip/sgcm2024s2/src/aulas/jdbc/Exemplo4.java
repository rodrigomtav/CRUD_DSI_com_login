package aulas.jdbc;

import controller.DataBaseConnection;
import java.sql.SQLException;

/*
Exemplo de INSERT e DELETE.
*/
public class Exemplo4 {
    public static void main(String[] args) throws SQLException {
        
        DataBaseConnection dbConnection = DataBaseConnection.getInstance();
        
//        dbConnection.executeSQL(" INSERT INTO tipo_usuario VALUES (13, 'Usuário 13', 'N', 'N', 'S') ");
        
        dbConnection.executeSQL(" DELETE FROM tipo_usuario WHERE id = 13 ");
        
        
    }
}