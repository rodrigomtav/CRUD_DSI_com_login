package aulas.jdbc;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

/*
Exemplo de SELECT.
*/
public class Exemplo2 {
    public static void main(String[] args) throws SQLException {
        
        // url
        String url = "jdbc:mysql://localhost:3307/SGCM-PROF";
        
        // user
        String user = "root";
        
        // password
        String pass = "root";
        
        // gerencia a conexão
        Connection connection = null;
        
        // criar conexão
        connection = DriverManager.getConnection( url, user, pass );
        
        // meio para script SQL
        Statement statement = null;
        
        // cria Statement para executar script SQL no banco de dados
        statement = connection.createStatement();
        
        // gerencia resultados
        ResultSet resultSet = null;
        
        // executa o script SQL de consulta no banco de dados
        resultSet = statement.executeQuery(" SELECT * FROM tipo_usuario ");
        
        // obter os nomes das colunas
        ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
        
        
        int ncol = resultSetMetaData.getColumnCount();
        for( int i = 1; i <= ncol; i++ ) {
            System.out.print( resultSetMetaData.getColumnLabel( i )  + " \t " );
        }
        System.out.print(" \n ");
        
        
        while( resultSet.next() ) { // percorre por linha
            
            for( int i = 1; i <= ncol; i++ ) { // percorre por coluna
                System.out.print( resultSet.getObject(i) + " \t " );
            }
            System.out.print(" \n ");
            
        }
        
        // fechar os "resultados" da consulta SQL
        resultSet.close();
        
        // fechar o "script" SQL
        statement.close();
        
        // fechar a conexão
        connection.close();
        
    }
}