package aulas.jdbc;

import controller.AppConfig;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
Exemplo de INSERT e DELETE.
*/
public class Exemplo3 {
    public static void main(String[] args) throws SQLException {
        
        // url
        String url = AppConfig.getUrl();
        
        // user
        String user = AppConfig.getUser();
        
        // password
        String pass = AppConfig.getPassword();
        
        // gerencia a conexão
        Connection connection = null;
        
        // criar conexão
        connection = DriverManager.getConnection( url, user, pass );
        
        // meio para script SQL
        Statement statement = null;
        
        // cria Statement para executar script SQL no banco de dados
        statement = connection.createStatement();
        
//        statement.execute(" INSERT INTO tipo_usuario VALUES (13, 'Usuário 13', 'N', 'N', 'S') ");

        statement.execute(" DELETE FROM tipo_usuario WHERE id = 13 ");
        
        // fechar o "script" SQL
        statement.close();
        
        // fechar a conexão
        connection.close();
        
    }
}