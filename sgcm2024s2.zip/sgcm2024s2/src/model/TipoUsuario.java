package model;

import controller.DataAccessObject;
import java.util.ArrayList;

/*
Um objeto da classe TipoUsuário representa uma linha de dados da tabela tipo_usuario no banco de dados relacional.

Um objeto deta classe é um objeto persistente.
*/
public class TipoUsuario extends DataAccessObject {
    
    private int id;
    private String nome;
    private String moduloAdministrativo;
    private String moduloAgendamento;
    private String moduloAtendimento;

    public TipoUsuario() {
        super("tipo_usuario");
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getModuloAdministrativo() {
        return moduloAdministrativo;
    }

    public String getModuloAgendamento() {
        return moduloAgendamento;
    }

    public String getModuloAtendimento() {
        return moduloAtendimento;
    }

    public void setId(int id) {
        if( this.id != id ) {
            this.id = id;
            addChange("id", this.id); // padrão Unity of Work
        }
    }

    public void setNome(String nome) {
        if( nome == null ) {
            if( this.nome != null ) {
                this.nome = nome;
                addChange("nome", null);
            }
        } else {
            if( !nome.equals(this.nome) ) {
                this.nome = nome;
                addChange("nome", this.nome);
            }
        }        
    }

    public void setModuloAdministrativo(String moduloAdministrativo) {
        if( moduloAdministrativo == null ) {
            if( this.moduloAdministrativo != null ) {
                this.moduloAdministrativo = moduloAdministrativo;
                addChange("modulo_administrativo", null);
            }
        } else {
            if( !moduloAdministrativo.equals(this.moduloAdministrativo) ) {
                this.moduloAdministrativo = moduloAdministrativo;
                addChange("modulo_administrativo", this.moduloAdministrativo);
            }
        }
    }

    public void setModuloAgendamento(String moduloAgendamento) {
        if( moduloAgendamento == null ) {
            if( this.moduloAgendamento != null ) {
                this.moduloAgendamento = moduloAgendamento;
                addChange("modulo_agendamento", null);
            }
        } else {
            if( !moduloAgendamento.equals(this.moduloAgendamento) ) {
                this.moduloAgendamento = moduloAgendamento;
                addChange("modulo_agendamento", this.moduloAgendamento);
            }
        }
    }

    public void setModuloAtendimento(String moduloAtendimento) {
       if( moduloAtendimento == null ) {
            if( this.moduloAtendimento != null ) {
                this.moduloAtendimento = moduloAtendimento;
                addChange("modulo_atendimento", null);
            }
        } else {
            if( !moduloAtendimento.equals(this.moduloAtendimento) ) {
                this.moduloAtendimento = moduloAtendimento;
                addChange("modulo_atendimento", this.moduloAtendimento);
            }
        } 
    }
    
    
    @Override
    public String getWhereClauseForOneEntry() {
        // utiliza os campos que são primary key
        return " id = " + this.id;
    }

    @Override
    protected void fill(ArrayList<Object> data) throws Exception {
        
        // a ordem de preenchimento dos atributos pelo index do ArrayList data deve ser a mesma ordem dos campus na tabela
        
        id = (int) data.get(0); // não é preciso verificar o null pois é primary key
        
        if( data.get(1) == null ) nome = null;
        else nome = (String) data.get(1);
        
        if( data.get(2) == null ) moduloAdministrativo = null;
        else moduloAdministrativo = (String) data.get(2);
        
        if( data.get(3) == null ) moduloAgendamento = null;
        else moduloAgendamento = (String) data.get(3);
        
        if( data.get(4) == null ) moduloAtendimento = null;
        else moduloAtendimento = (String) data.get(4);
        
    }

    
    @Override
    public boolean equals(Object obj) {
        if( obj instanceof TipoUsuario ) {
            TipoUsuario aux = (TipoUsuario) obj;
            
            if( getId() == aux.getId() ) {
                return true;
            } else {
                return false;
            }            
        } else { 
            return false;
        }        
    }
    
}