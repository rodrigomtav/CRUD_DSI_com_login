package model;

import controller.DataAccessObject;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;

public class Usuario extends DataAccessObject {
    
    
    private int id;
    private String nome;
    private String dataNascimento;
    private String cpf;
    private String endereco;
    private String senha;
    private TipoUsuario tipoUsuario; // associação entre objetos persistentes de "um para um" (1 --- 1)

    
    public Usuario() {
        super("usuarios");
    }

    
    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public String getCpf() {
        return cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getSenha() {
        return senha;
    }
    
    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }
    
    public void setId(int id) {
        if( id != this.id ) {
            this.id = id;
            addChange("id", this.id);
        }
    }

    public void setNome(String nome) {
        if( nome == null ) {
            if( this.nome != null ) {
                this.nome = nome;
                addChange("nome", null);
            }
        } else {
            if( !nome.equals(this.nome) ) {
                this.nome = nome;
                addChange("nome", this.nome);
            }
        }
    }

    public void setDataNascimento(String dataNascimento) {
        if( dataNascimento == null ) {
            if( this.dataNascimento != null ) {
                this.dataNascimento = dataNascimento;
                addChange("data_nascimento", null);
            }
        } else {
            if( !dataNascimento.equals(this.dataNascimento) ) {
                this.dataNascimento = dataNascimento;
                addChange("data_nascimento", this.dataNascimento);
            }
        }
    }

    public void setCpf(String cpf) {
        if( cpf == null ) {
            if( this.cpf != null ) {
                this.cpf = cpf;
                addChange("cpf", null);
            }
        } else {
            if( !cpf.equals(this.cpf) ) {
                this.cpf = cpf;
                addChange("cpf", this.cpf);
            }
        }
    }

    public void setEndereco(String endereco) {
        if( endereco == null ) {
            if( this.endereco != null ) {
                this.endereco = endereco;
                addChange("endereco", null);
            }
        } else {
            if( !endereco.equals(this.endereco) ) {
                this.endereco = endereco;
                addChange("endereco", this.endereco);
            }
        }
    }

    private String getSenhaHash(String senha) throws Exception{
        //sal de bits
        senha = String.valueOf(id) + senha;
        
        MessageDigest md = MessageDigest.getInstance("SHA-256");
                
        String hash;
        hash = new BigInteger(md.digest( ( senha.getBytes("UTF-8") ) ) ).toString(16);
        return hash;
    }
    
    public void setSenha(String senha) throws Exception{
        if( senha == null ) {
            if( this.senha != null ) {
                this.senha = senha;
                addChange("senha", null);
            }
        } else {
            if( !senha.equals(this.senha) ) {
                this.senha = getSenhaHash(senha);
                addChange("senha", this.senha);
            }
        }
    }

    public void setTipoUsario(TipoUsuario tipoUsario) throws Exception {
        if( tipoUsario == null ) {
            if( this.tipoUsuario != null ) {
                this.tipoUsuario = tipoUsario;
                addChange("tipo_usuario_id", null);
            }
        } else {
            if( this.tipoUsuario == null ) {
                this.tipoUsuario = new TipoUsuario();
                this.tipoUsuario.setId( tipoUsario.getId() );
                this.tipoUsuario.load();
                addChange( "tipo_usuario_id", this.tipoUsuario.getId() );
            } else {
                if( !tipoUsario.equals( this.tipoUsuario ) ) { // é precriso fazer um @Override do método equals na classe TipoUsuario
                    this.tipoUsuario.setId( tipoUsario.getId() );
                    this.tipoUsuario.load();
                    addChange( "tipo_usuario_id", this.tipoUsuario.getId() );
                }
            }
        }
    }
    
    
    @Override
    protected String getWhereClauseForOneEntry() {
        return " id = " + this.id;
    }

    @Override
    protected void fill(ArrayList<Object> data) throws Exception {
        
        id = (int) data.get(0);
        
        if( data.get(1) == null ) nome = null;
        else nome = (String) data.get(1);
        
        if( data.get(2) == null ) dataNascimento = null;
        else dataNascimento = data.get(2).toString();
        
        if( data.get(3) == null ) cpf = null;
        else cpf = (String) data.get(3);
        
        if( data.get(4) == null ) endereco = null;
        else endereco = (String) data.get(4);
        
        if( data.get(5) == null ) senha = null;
        else senha = (String) data.get(5);
        
        if( data.get(6) != null ) {
            tipoUsuario = new TipoUsuario();
            tipoUsuario.setId( (int) data.get(6) );
            tipoUsuario.load();
        } else {
            tipoUsuario = null;
        }
        
    }
    
}