package model;

import controller.DataAccessObject;
import java.util.ArrayList;

public class Laboratorio extends DataAccessObject {
    
    private int id;
    private String nome;
    private String cnpj;
    private String observacao;
    
    public Laboratorio() {
        super("laboratorios");
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getCnpj() {
        return cnpj;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setId(int id) {
        if( id != this.id ) {
            this.id = id;
            addChange("id", this.id);
        }
    }

    public void setNome(String nome) {
        if( nome == null ) {
            if( this.nome != null ) {
                this.nome = nome;
                addChange("nome", null);
            }
        } else {
            if( !nome.equals(this.nome) ) {
                this.nome = nome;
                addChange("nome", this.nome);
            }
        }
    }

    public void setCnpj(String cnpj) {
        if( cnpj == null ) {
            if( this.cnpj != null ) {
                this.cnpj = cnpj;
                addChange("cnpj", null);
            }
        } else {
            if( !cnpj.equals(this.cnpj) ) {
                this.cnpj = cnpj;
                addChange("cnpj", this.cnpj);
            }
        }
    }

    public void setObservacao(String observacao) {
        if( observacao == null ) {
            if( this.observacao != null ) {
                this.observacao = observacao;
                addChange("observacao", null);
            }
        } else {
            if( !observacao.equals(this.observacao) ) {
                this.observacao = observacao;
                addChange("observacao", this.observacao);
            }
        }
    }
    
    @Override
    protected String getWhereClauseForOneEntry() {
        return " id = " + this.id;
    }

    @Override
    protected void fill(ArrayList<Object> data) {
        
        id = (int) data.get(0);
        
        if( data.get(1) == null ) nome = null;
        else nome = (String) data.get(1);
        
        if( data.get(2) == null ) cnpj = null;
        else cnpj = data.get(2).toString();
        
        if( data.get(3) == null ) observacao = null;
        else observacao = (String) data.get(3);
        
    }

}