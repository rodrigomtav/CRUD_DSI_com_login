# DSIS4 -- Sistema de Gerenciamento de Clínica Médica (SGCM)

## Git Config

git config --global user.name "Mario Popolin Neto"

git config --global user.email "mariopopolin@ifsp.edu.br"

---
